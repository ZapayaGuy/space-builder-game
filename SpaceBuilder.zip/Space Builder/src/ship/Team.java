package ship;

public enum Team {
	PLAYER, 
	DERELICT, 
	ENEMY;
}
