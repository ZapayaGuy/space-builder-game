package ship;

public interface BlockUpdateable {
	public void update(double time_S);
}
