package ship;

public enum FiringMode {
	SHOOT_AT_CLOSEST, MOUSE_CONTROL;
}
