package block;

public class Bulwark extends Block{

	public Bulwark(double x, double y) {
		super(x, y);
		this.setHealth(5);
		this.setMass(2);
	}

}
