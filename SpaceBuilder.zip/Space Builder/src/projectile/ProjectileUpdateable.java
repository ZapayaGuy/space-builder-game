package projectile;

public interface ProjectileUpdateable {
	public void update(double time_S);
}
